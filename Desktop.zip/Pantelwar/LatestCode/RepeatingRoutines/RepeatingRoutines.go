package main

import (
	"fmt"
	"net/http"
	"sync"
	// "time"
)

func main() {
	websiteList := []string{
		"https://www.google.com",
		"https://go.dev",
	}
}

func CheckLink(s string,chan c string) {
	
}
