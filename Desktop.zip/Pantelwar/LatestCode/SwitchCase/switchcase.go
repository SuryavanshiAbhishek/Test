package main

import (
	"fmt"
)

func main() {
	fmt.Println("Learning Switch Case")
	val:=10
	switch val{
	case 20:
		fmt.Println("20")
	case 30:
	    fmt.Println("30")
	case 10:
		fmt.Println("10")
	}
}
